# How to Use This macOS Script

## Setup Instructions

1. Save the file as `game_macos.sh`
2. Make the script executable by running this command in Terminal:
   ```bash
   chmod +x game_macos.sh
   ```
3. Run the script:
   ```bash
   ./game_macos.sh
   ```
if can not install http-server try "sudo npm install http-server -g" then run again